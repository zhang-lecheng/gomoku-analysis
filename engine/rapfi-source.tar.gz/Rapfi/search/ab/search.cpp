/*
 *  Rapfi, a Gomoku/Renju playing engine supporting piskvork protocol.
 *  Copyright (C) 2022  Rapfi developers
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "../../core/hash.h"
#include "../../core/iohelper.h"
#include "../../core/platform.h"
#include "../../database/dbclient.h"
#include "../../eval/eval.h"
#include "../../eval/evaluator.h"
#include "../../game/board.h"
#include "../../game/movegen.h"
#include "../../game/wincheck.h"
#include "../hashtable.h"
#include "../movepick.h"
#include "../opening.h"
#include "../searchconfig.h"
#include "../searchthread.h"
#include "../skill.h"
#include "parameter.h"
#include "searcher.h"
#include "searchstack.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <iomanip>
#include <limits>
#include <optional>
#include <random>
#include <tuple>

using namespace Search;
using namespace Search::AB;

namespace {

enum NodeType { Root, PV, NonPV };

#ifdef POLICY_TRAINING
struct DeferredPolicyTrace
{
    Pos                            move             = Pos::NONE;
    Tuning::PolicyTraceFilter      filter           = Tuning::PolicyTraceFilter::None;
    Tuning::PolicyTraceDisposition disposition      = Tuning::PolicyTraceDisposition::Pending;
    int32_t                        alphaBefore      = 0;
    uint16_t                       moveCount        = 0;
    Depth                          plannedReduction = 0;
    std::array<Depth, 4>            searchDepths {};
    uint8_t                        searchCount      = 0;
    int32_t                        value            = VALUE_NONE;
    Bound                          bound            = BOUND_NONE;
    uint64_t                       nodes            = 0;
    bool                           alphaChanged     = false;
    bool                           valid            = false;
};

void recordPolicyTraceSearch(DeferredPolicyTrace &trace, Depth depth)
{
    if (trace.searchCount >= trace.searchDepths.size())
        throw std::logic_error("policy trace candidate exceeded search-depth capacity");
    trace.searchDepths[trace.searchCount++] = depth;
}

void applyDeferredPolicyTrace(Tuning::PolicyTraceCandidate &candidate,
                              const DeferredPolicyTrace    &deferred)
{
    candidate.filter           = deferred.filter;
    candidate.disposition      = deferred.disposition;
    candidate.alphaBefore      = deferred.alphaBefore;
    candidate.moveCount        = deferred.moveCount;
    candidate.plannedReduction = deferred.plannedReduction;
    candidate.searchDepths     = deferred.searchDepths;
    candidate.searchCount      = deferred.searchCount;
    candidate.value            = deferred.value;
    candidate.bound            = deferred.bound;
    candidate.nodes            = deferred.nodes;
    candidate.alphaChanged     = deferred.alphaChanged;
}

template <NodeType NT>
void initializePolicyTraceEvent(MovePicker          &mp,
                                SearchStack         *ss,
                                Value                alpha,
                                Value                beta,
                                Depth                depth,
                                bool                 cutNode,
                                DeferredPolicyTrace &deferred,
                                bool                &initialized)
{
    Tuning::PolicyTraceEvent *event = mp.policyTraceEvent();
    if (!event || initialized)
        return;
    event->nodeType = NT == Root ? Tuning::PolicyTraceNodeType::Root
                      : NT == PV ? Tuning::PolicyTraceNodeType::Pv
                                 : Tuning::PolicyTraceNodeType::NonPv;
    event->cutNode  = cutNode;
    event->ply      = static_cast<int16_t>(ss->ply);
    event->depth    = depth;
    event->alpha    = alpha;
    event->beta     = beta;
    event->singularExcludedMove = ss->skipMove;
    initialized     = true;

    if (deferred.valid)
        if (Tuning::PolicyTraceCandidate *candidate = mp.policyTraceCandidate(deferred.move))
            applyDeferredPolicyTrace(*candidate, deferred);
    if (ss->skipMove)
        if (Tuning::PolicyTraceCandidate *candidate = mp.policyTraceCandidate(ss->skipMove)) {
            candidate->filter      = Tuning::PolicyTraceFilter::SingularExcluded;
            candidate->disposition = Tuning::PolicyTraceDisposition::SingularExcluded;
        }
}

void finishPolicyTraceEvent(MovePicker   &mp,
                            SearchThread &thread,
                            uint64_t      nodeStart,
                            Time          eventStart,
                            Value         bestValue,
                            Pos           bestMove,
                            Bound         bound)
{
    Tuning::PolicyTraceEvent *event = mp.policyTraceEvent();
    if (!event)
        return;
    while (mp()) {}
    std::vector<bool> usedSelectionOrdinals(event->candidates.size());
    for (Tuning::PolicyTraceCandidate &candidate : event->candidates) {
        if (candidate.selectionOrdinal < event->candidates.size()
            && !usedSelectionOrdinals[candidate.selectionOrdinal])
            usedSelectionOrdinals[candidate.selectionOrdinal] = true;
        else
            candidate.selectionOrdinal = std::numeric_limits<uint16_t>::max();
    }
    size_t nextSelectionOrdinal = 0;
    for (Tuning::PolicyTraceCandidate &candidate : event->candidates) {
        if (candidate.selectionOrdinal != std::numeric_limits<uint16_t>::max())
            continue;
        while (usedSelectionOrdinals[nextSelectionOrdinal])
            nextSelectionOrdinal++;
        candidate.selectionOrdinal = static_cast<uint16_t>(nextSelectionOrdinal);
        usedSelectionOrdinals[nextSelectionOrdinal] = true;
    }
    if (event->nodeType == Tuning::PolicyTraceNodeType::Root) {
        event->rootEligibleMoves.reserve(thread.rootMoves.size());
        for (const RootMove &rootMove : thread.rootMoves)
            event->rootEligibleMoves.push_back(rootMove.pv[0]);
        for (Tuning::PolicyTraceCandidate &candidate : event->candidates)
            if (!std::count(thread.rootMoves.begin(), thread.rootMoves.end(), candidate.move)) {
                candidate.filter      = Tuning::PolicyTraceFilter::RootExcluded;
                candidate.disposition = Tuning::PolicyTraceDisposition::Filtered;
            }
    }
    const bool observedCutoff =
        std::any_of(event->candidates.begin(),
                    event->candidates.end(),
                    [](const Tuning::PolicyTraceCandidate &candidate) {
                        return candidate.disposition
                               == Tuning::PolicyTraceDisposition::SearchedCutoff;
                    });
    for (Tuning::PolicyTraceCandidate &candidate : event->candidates) {
        if (candidate.disposition != Tuning::PolicyTraceDisposition::Pending)
            continue;
        if (!observedCutoff) {
            mp.discardPolicyTrace();
            return;
        }
        candidate.disposition = Tuning::PolicyTraceDisposition::PostCutoffCensored;
    }
    std::vector<Tuning::PolicyTraceCandidate *> eligibleCandidates;
    for (Tuning::PolicyTraceCandidate &candidate : event->candidates) {
        if (candidate.filter == Tuning::PolicyTraceFilter::None)
            eligibleCandidates.push_back(&candidate);
        else
            candidate.policyOrdinal = std::numeric_limits<uint16_t>::max();
    }
    std::sort(eligibleCandidates.begin(),
              eligibleCandidates.end(),
              [](const auto *lhs, const auto *rhs) {
                  return lhs->policyOrdinal < rhs->policyOrdinal;
              });
    if (!eligibleCandidates.empty()
        && eligibleCandidates.back()->policyOrdinal == std::numeric_limits<uint16_t>::max())
        throw std::logic_error("policy trace contains an eligible unreturned candidate");
    for (size_t ordinal = 0; ordinal < eligibleCandidates.size(); ordinal++)
        eligibleCandidates[ordinal]->policyOrdinal = static_cast<uint16_t>(ordinal);
    event->totalNodes   = thread.numNodes.load(std::memory_order_relaxed) - nodeStart;
    event->elapsedTicks = static_cast<uint64_t>(now() - eventStart);
    event->bestMove     = bestMove;
    event->bestValue    = bestValue;
    event->bestBound    = bound;
    event->completion   = Tuning::PolicyTraceCompletion::Complete;
    mp.commitPolicyTrace();
}
#endif

/// Stable-sort root moves [begin, end) best-first: by distance to the balanced
/// eval (with `balanceBias`) in balance mode, by value otherwise. Stable sorting
/// keeps the previous order of equal-valued moves (during a MultiPV iteration all
/// values except the searched PV lines are VALUE_NONE).
void sortRootMoves(RootMoves::iterator begin,
                   RootMoves::iterator end,
                   bool                balanceMode,
                   int                 balanceBias = 0)
{
    if (balanceMode)
        std::stable_sort(begin, end, BalanceMoveValueComparator {balanceBias});
    else
        std::stable_sort(begin, end, RootMoveValueComparator {});
}

void aspirationSearch(Rule rule, Board &board, SearchStack *ss, Value prevValue, Depth depth);
template <NodeType NT = PV>
Value search(Rule         rule,
             Board       &board,
             SearchStack *ss,
             Value        alpha,
             Value        beta,
             Depth        depth,
             bool         cutNode);
template <Rule Rule, NodeType NT>
Value search(Board &board, SearchStack *ss, Value alpha, Value beta, Depth depth, bool cutNode);
template <Rule Rule, NodeType NT>
Value vcfsearch(Board &board, SearchStack *ss, Value alpha, Value beta, Depth depth = 0.0f);
template <Rule Rule, NodeType NT>
Value vcfdefend(Board &board, SearchStack *ss, Value alpha, Value beta, Depth depth = 0.0f);

}  // namespace

void ABSearchData::clearData(SearchThread &th)
{
    multiPv         = 1;
    pvIdx           = 0;
    rootDepth       = 0;
    completedDepth  = 0;
    bestMoveChanges = 0;
    singularRoot    = false;
    mainHistory.init(0);
    counterMoveHistory.init(std::make_pair(Pos::NONE, NONE));
}

void ABSearcher::setMemoryLimit(size_t memorySizeKB)
{
    TT.resize(memorySizeKB);
}

size_t ABSearcher::getMemoryLimit() const
{
    return TT.hashSizeKB();
}

void ABSearcher::clear(SearchEngine &pool, bool clearAllMemory)
{
    // The reduction LUT and the shared TT are read by search threads; make
    // sure none is still draining a stopped search before rewriting them.
    pool.waitForIdle();

    // Clear time control variables for one game
    previousTimeReduction = 1.0f;
    previousBestValue     = VALUE_NONE;

    initReductionLUT(reductions, pool.size());

    if (clearAllMemory)
        TT.clear();
}

const RootMove *ABSearcher::searchMain(SearchThread &th)
{
    SearchContext &ctx  = th.engine.ctx;
    SearchOptions &opts = th.options();

    // Check for forced database move
    Pos   dbWinMove  = Pos::NONE;
    Value dbWinValue = VALUE_NONE;
    int   dbWinDepth = 0;
    if (th.dbClient) {
        auto childRecords = th.dbClient->queryChildren(*th.board, opts.rule);

        Pos   bestMove      = Pos::NONE;
        Value bestMoveValue = VALUE_NONE;
        for (auto &[pos, record] : childRecords) {
            if (record.label == Database::LABEL_WIN && Value(-record.value) > dbWinValue) {
                dbWinMove  = pos;
                dbWinValue = std::max(Value(-record.value), VALUE_MATE_FROM_DATABASE);
                dbWinDepth = record.depth();
            }
            else if (record.label == Database::LABEL_FORCEMOVE  // A forced best move
                     && Value(record.value) > bestMoveValue) {
                bestMove      = pos;
                bestMoveValue = Value(record.value);
            }
        }

        if (bestMove) {
            ctx.bestMove = bestMove;
            ctx.printer.printBestmoveWithoutSearch(th, bestMove, bestMoveValue, 0, nullptr);
            return nullptr;
        }
    }

    // Init transposition table generation
    TT.incGeneration();

    // Starts worker threads, then starts main thread
    ctx.printer.printSearchStarts(th, ctx.timectl);
    th.engine.runOnAllThreads([this](SearchThread &t) { search(t); }, true);

    // Select best thread according to eval and completed depth when needed
    SearchThread *bestThread = &th;
    if (opts.multiPV == 1 && !SkillMovePicker(opts.strengthLevel).enabled() && !opts.balanceMode)
        bestThread = pickBestThread(th.engine);

    if (opts.balanceMode == SearchOptions::BALANCE_NONE && dbWinMove
        && bestThread->rootMoves[0].value < VALUE_MATE_IN_MAX_PLY) {
        // Try to move the winning move to front
        auto rm = std::find(bestThread->rootMoves.begin(), bestThread->rootMoves.end(), dbWinMove);
        if (rm != bestThread->rootMoves.end()) {
            rm->value = dbWinValue;
            std::stable_sort(bestThread->rootMoves.begin(),
                             bestThread->rootMoves.end(),
                             RootMoveValueComparator {});
        }
        // If database winning move is not in rootmoves, return it directly
        else {
            ctx.bestMove = dbWinMove;
            ctx.printer.printBestmoveWithoutSearch(th, dbWinMove, dbWinValue, dbWinDepth, nullptr);
            return nullptr;
        }
    }

    // Output search statistic information
    ctx.printer.printSearchEnds(th,
                                ctx.timectl,
                                bestThread->searchDataAs<ABSearchData>()->completedDepth,
                                *bestThread);

    return &bestThread->rootMoves[0];
}

void ABSearcher::search(SearchThread &th)
{
    ABSearchData  &sd        = *th.searchDataAs<ABSearchData>();
    SearchContext &ctx       = th.engine.ctx;
    SearchOptions &options   = th.options();
    Value          initValue = Evaluation::evaluate(*th.board, options.rule);
    StackArray     stackArray(MAX_PLY, initValue);
    Value          bestValue           = -VALUE_INFINITE;
    Pos            lastBestMove        = Pos::NONE;
    int            lastMoveChangeDepth = 0;
    float          timeReduction = 1.0f, totalBestMoveChanges = 0.0f;
    int            firstMateDepth = 0, firstSingularDepth = 0;
    SearchThread  *mainThread = (&th == th.engine.main() ? th.engine.main() : nullptr);

    // Init search depth range
    int maxDepth   = std::min(options.maxDepth, std::clamp(SearchCfg.maxSearchDepth, 2, MAX_DEPTH));
    int startDepth = std::clamp(options.startDepth, 1, maxDepth);

    // Init random move picker and adjust max depth and multiPV
    SkillMovePicker rmp(options.strengthLevel);
    sd.multiPv = options.multiPV;
    if (rmp.enabled()) {
        maxDepth   = std::min(maxDepth, rmp.pickDepth());
        sd.multiPv = std::max(sd.multiPv, rmp.minMultiPv());
    }

    // Limit multiPV to the size of root moves
    sd.multiPv = std::min<uint32_t>(sd.multiPv, th.rootMoves.size());

    for (sd.rootDepth = startDepth; sd.rootDepth <= maxDepth && !th.engine.isTerminating();
         sd.rootDepth = pickNextDepth(th.engine, th.id, sd.rootDepth)) {
        // Sync modifications in database client to database storage
        if (th.dbClient && ctx.timectl.elapsed() > 5000)
            th.dbClient->sync(false);

        // Age out PV variability metric when depth increases
        totalBestMoveChanges *= 0.5;

        // Save the last iteration's values and PVs before first PV line is searched
        // and all the move values except the (new) PV are set to VALUE_NONE.
        for (RootMove &rm : th.rootMoves) {
            rm.previousValue = rm.value;
            rm.previousPv    = rm.pv;
        }

        // MultiPV loop. We perform a full root search for each PV line
        for (sd.pvIdx = 0; sd.pvIdx < sd.multiPv && !th.engine.isTerminating(); ++sd.pvIdx) {
            // Reset selDepth for each depth and each PV line
            th.selDepth = 0;

            // Do (aspiration window) search using previous value of current pv
            aspirationSearch(options.rule,
                             *th.board,
                             stackArray.rootStack(),
                             th.rootMoves[sd.pvIdx].previousValue,
                             Depth(sd.rootDepth));

            // Send out various information to GUI
            if (mainThread)
                ctx.printer.printPvCompletes(*mainThread,
                                             ctx.timectl,
                                             sd.rootDepth,
                                             sd.pvIdx,
                                             sd.multiPv);

            // Sort the PV lines searched so far. When we are in balance move mode,
            // sort according to negative absolute value rather than its original value.
            sortRootMoves(th.rootMoves.begin(),
                          th.rootMoves.begin() + sd.pvIdx + 1,
                          options.balanceMode,
                          options.balanceBias);
        }

        // If search is complete, update completed depth.
        if (!th.engine.isTerminating()) {
            sd.completedDepth = sd.rootDepth;
        }

        // Update the best eval and best move.
        bestValue = th.rootMoves[0].value;
        if (th.rootMoves[0].pv[0] != lastBestMove) {
            lastBestMove        = th.rootMoves[0].pv[0];
            lastMoveChangeDepth = sd.rootDepth;
        }

        if (!mainThread)
            continue;

        // Check if we have won or lost, or having only one legal move.
        bool isMate = std::abs(th.rootMoves[0].value) >= VALUE_MATE_IN_MAX_PLY;
        if (isMate && !firstMateDepth)
            firstMateDepth = sd.rootDepth;
        if (sd.singularRoot && !firstSingularDepth)
            firstSingularDepth = sd.rootDepth;

        // Stop thinking if we are not in analysis mode, inPonder mode, or random move mode
        if (!options.isAnalysisMode() && !ctx.inPonder && !rmp.enabled()) {
            if (isMate && sd.rootDepth - firstMateDepth >= SearchCfg.numIterationAfterMate)
                th.engine.stopThinking();
            else if (sd.singularRoot
                     && sd.rootDepth - firstSingularDepth
                            >= SearchCfg.numIterationAfterSingularRoot) {
                ctx.markPonderingAvailable();
                th.engine.stopThinking();
            }
        }

        // Send out search result of this depth
        if (mainThread)
            ctx.printer.printDepthCompletes(*mainThread, ctx.timectl, sd.completedDepth);

        // Check do we have time for the next iteration?
        if (options.timeLimit && !th.engine.isTerminating()) {
            // Accumulate all best move changes across threads
            for (const auto &t : th.engine) {
                ABSearchData &tsd = *t->searchDataAs<ABSearchData>();
                totalBestMoveChanges += tsd.bestMoveChanges.exchange(0);
            }

            // Stop the search if exceeds time limit (do not stop in inPonder mode)
            if (ctx.timectl.checkStop({sd.rootDepth,
                                       lastMoveChangeDepth,
                                       bestValue,
                                       previousBestValue,
                                       previousTimeReduction,
                                       totalBestMoveChanges / th.engine.size()},
                                      timeReduction)
                && !ctx.inPonder) {
                // Start pondering after foreground searching naturally ended
                ctx.markPonderingAvailable();
                th.engine.stopThinking();
            }
        }
    }

    // Sync modifications in database client to database storage
    if (th.dbClient)
        th.dbClient->sync();

    if (!mainThread)
        return;

    // Save time adjustment information for next search
    previousBestValue     = bestValue;
    previousTimeReduction = timeReduction;

    // If random move picker is enabled, swap best PV line with a sub-optimal one
    if (rmp.enabled()) {
        std::swap(
            th.rootMoves[0],
            *std::find(th.rootMoves.begin(), th.rootMoves.end(), rmp.pick(th.engine, sd.multiPv)));
    }
}

bool ABSearcher::checkTimeupCondition(const TimeControl &timectl)
{
    return timectl.elapsed() >= timectl.maximum();
}

int ABSearcher::pickNextDepth(SearchEngine &threads, uint32_t thisId, int lastDepth) const
{
    if (thisId == 0 || threads.size() < 3)
        return lastDepth + 1;

    for (int nextDepth = lastDepth + 1;; nextDepth++) {
        size_t numThreadsAboveNextDepth = 0;

        for (const auto &th : threads) {
            if (th->id != thisId
                && th->searchDataAs<ABSearchData>()->completedDepth + 1 >= nextDepth)
                numThreadsAboveNextDepth++;
        }

        // If more than half of all threads are already searching depth above
        // the next depth, skip and find another next depth.
        if (numThreadsAboveNextDepth > threads.size() / 2)
            continue;
        else
            return nextDepth;
    }
}

SearchThread *ABSearcher::pickBestThread(SearchEngine &threads) const
{
    SearchThread *bestThread = threads.main();

    // In case of database recording mode, only use main thread result.
    if (bestThread->dbClient && !threads.ctx.dbParams.readonlyMode)
        return bestThread;

    // Find minimum value of all threads
    Value minValue = bestThread->rootMoves[0].value;
    for (size_t i = 1; i < threads.size(); i++)
        minValue = std::min(minValue, threads[i]->rootMoves[0].value);

    // Vote moves according to value and depth
    std::unordered_map<Pos, int64_t> votes;
    constexpr int                    DepthBias = 15;
    for (const auto &th : threads) {
        Pos   move  = th->rootMoves[0].pv[0];
        Value value = th->rootMoves[0].value;

        votes[move] +=
            (value - minValue + DepthBias) * th->searchDataAs<ABSearchData>()->completedDepth;

        // If best thread has a winning move, other threads must have a shorter
        // mate to replace it.
        if (std::abs(bestThread->rootMoves[0].value) >= VALUE_MATE_IN_MAX_PLY) {
            if (value > bestThread->rootMoves[0].value)
                bestThread = th.get();
        }
        // Else if current thread has a winning/lossing move while best thread
        // has not, replace best thread with current thread.
        else if (std::abs(value) >= VALUE_MATE_IN_MAX_PLY && value != VALUE_NONE) {
            bestThread = th.get();
        }
        // Else if current thread has a non-lossing move, select best thread
        // according to votes.
        else if (value > VALUE_MATED_IN_MAX_PLY
                 && votes[move] > votes[bestThread->rootMoves[0].pv[0]]) {
            bestThread = th.get();
        }
    }

    return bestThread;
}

namespace {

/// The aspiration window search loop. First start with a small aspiration window, in the case
/// of a fail high/low, re-search with a bigger window until we don't fail high/low anymore.
void aspirationSearch(Rule rule, Board &board, SearchStack *ss, Value prevValue, Depth depth)
{
    assert(rule < RULE_NB);

    Value          delta, alpha, beta;
    SearchThread  *thisThread  = board.thisThread();
    ABSearchData  *searchData  = thisThread->searchDataAs<ABSearchData>();
    SearchContext &ctx         = thisThread->engine.ctx;
    int            failHighCnt = 0;

    // Reset aspiration window starting size if aspiration windows is enabled and
    // we are not in balance move mode (no aspiration window for balance move mode).
    // A window needs a real previous value to center on: the first search of a PV
    // line (e.g. a high startDepth) has none and must use the full window.
    if (depth >= ASPIRATION_DEPTH && SearchCfg.aspirationWindow && prevValue != VALUE_NONE
        && !thisThread->options().balanceMode) {
        delta = nextAspirationWindowDelta(rule, prevValue);
        alpha = std::max(prevValue - delta, -VALUE_INFINITE);
        beta  = std::min(prevValue + delta, VALUE_INFINITE);
    }
    else {
        alpha = delta = -VALUE_INFINITE;
        beta          = VALUE_INFINITE;
    }

    // Loop until we got a search value that lies in the aspiration window.
    while (true) {
        searchData->rootAlpha = alpha;

        // Decrease search depth if multiple fail high occurs
        Depth adjustedDepth = std::max(1.0f, depth - failHighCnt / 3);

        // Search at root node with rule
        Value value = ::search<Root>(rule, board, ss, alpha, beta, adjustedDepth, false);

        // Bring the best move to the front. Stable sorting is used as all the value but the first
        // are set to -VALUE_INFINITE and we want to keep the same order for all the moves except
        // the new PV that goes to the front.
        // In case of MultiPV search, the already searched PV lines are preserved.
        // When in balance mode, sort according to negative absolute value.
        // (Deliberately bias-less here, matching the original behavior.)
        sortRootMoves(thisThread->rootMoves.begin() + searchData->pvIdx,
                      thisThread->rootMoves.end(),
                      thisThread->options().balanceMode);

        // If search has been stopped, break immediately. Sorting result is safe to use.
        if (thisThread->engine.isTerminating())
            break;

        // Update current move's sel depth
        thisThread->rootMoves[searchData->pvIdx].selDepth = thisThread->selDepth;

        // Print value out of window result
        if (value <= alpha || value >= beta)
            ctx.printer.printOutOfWindowResult(*thisThread,
                                               ctx.timectl,
                                               searchData->rootDepth,
                                               searchData->pvIdx,
                                               searchData->multiPv,
                                               alpha,
                                               beta);

        // In case of failing low/high increase aspiration window and re-search,
        // otherwise exit the loop.
        if (value <= alpha) {
            beta        = (alpha + beta) / 2;
            alpha       = std::max(value - delta, -VALUE_INFINITE);
            failHighCnt = 0;
        }
        else if (value >= beta) {
            beta = std::min(value + delta, VALUE_INFINITE);
            failHighCnt++;
        }
        else
            break;

        delta = nextAspirationWindowDelta(rule, value, delta);
        assert(alpha >= -VALUE_INFINITE && beta <= VALUE_INFINITE);
    }
}

/// Dynamic dispatch templated search() with correct rule. It is also
/// responsible for iterating the first move in balance2 mode.
template <NodeType NT>
Value search(Rule         rule,
             Board       &board,
             SearchStack *ss,
             Value        alpha,
             Value        beta,
             Depth        depth,
             bool         cutNode)
{
    assert(rule < RULE_NB);

    auto searchWithRule = [&](Rule r) {
        switch (r) {
        default:
        case Rule::FREESTYLE:
            return search<Rule::FREESTYLE, NT>(board, ss, alpha, beta, depth, cutNode);
        case Rule::STANDARD:
            return search<Rule::STANDARD, NT>(board, ss, alpha, beta, depth, cutNode);
        case Rule::RENJU: return search<Rule::RENJU, NT>(board, ss, alpha, beta, depth, cutNode);
        }
    };

    // Loop for first move in balance move mode
    SearchThread *thisThread = board.thisThread();
    if (NT == Root && thisThread->options().balanceMode == SearchOptions::BALANCE_TWO) {
        Value bestValue = -VALUE_INFINITE;
        ss->moveCount   = 0;
        MovePicker mp(rule,
                      board,
                      MovePicker::ExtraArgs<MovePicker::MAIN> {
                          thisThread->rootMoves[0].pv[0],
                          makeMoveHistoryScoring(
                              rule,
                              board.sideToMove(),
                              thisThread->searchDataAs<ABSearchData>()->mainHistory,
                              thisThread->searchDataAs<ABSearchData>()->counterMoveHistory),
                      });

        // Refresh root move index in balance2Moves
        for (size_t i = 0; i < thisThread->rootMoves.size(); i++) {
            Balance2Move b2move {thisThread->rootMoves[i].pv[0], thisThread->rootMoves[i].pv[1]};
            thisThread->balance2Moves[b2move] = i;
        }

        // Iterate first move in balance2 move pair
        while (Pos move = mp()) {
            board.move(rule, move);
            Value value = searchWithRule(rule);
            board.undo(rule);
            assert(value <= 0);

            // Check for a new best value and update alpha, beta
            if (value > bestValue) {
                bestValue = value;
                if (value > alpha) {
                    alpha = value;
                    beta  = -alpha;
                    // Break if search window size reaches zero
                    if (alpha >= beta)
                        return bestValue;
                }
            }
        }
        return bestValue;
    }
    else {
        return searchWithRule(rule);
    }
}

/// Holds the result of a database probe at a node, consumed by the later steps
/// of search<Rule,NT> (shallow-pruning gate, terminate-write, record write,
/// best-value adjust).
struct DBProbeState
{
    Database::DBRecord record;  // valid only when hit
    bool               hit        = false;
    bool               checkChild = false;  // child records may exist: disables shallow pruning
    Bound              labelBound = BOUND_NONE;  // bound implied by a WIN/LOSE/DRAW label
    Bound              bound      = BOUND_NONE;  // bound from the record's depth-bound field
    Value              value      = VALUE_NONE;  // record value converted to a search value
};

/// Step 5 of search<Rule,NT>: query the database and try a database cut.
/// May widen (alpha, beta) to the full window for PV database cuts.
/// @return A value to return immediately from the node (block move or database
///     cut), or std::nullopt to continue searching.
template <Rule Rule, NodeType NT>
std::optional<Value> probeDatabaseAtNode(Board        &board,
                                         SearchStack  *ss,
                                         Value        &alpha,
                                         Value        &beta,
                                         Depth         depth,
                                         HashKey       posKey,
                                         DBProbeState &db)
{
    constexpr bool PvNode   = NT == PV || NT == Root;
    constexpr bool RootNode = NT == Root;

    SearchThread *thisThread = board.thisThread();
    if (!thisThread->dbClient)
        return std::nullopt;

    ABSearchData               *searchData = thisThread->searchDataAs<ABSearchData>();
    SearchOptions              &options    = thisThread->options();
    const DatabaseSearchParams &dbParams   = thisThread->engine.ctx.dbParams;

    Database::DBClient &dbClient = *thisThread->dbClient;
    int                 queryPlyIncrement =
        searchData->rootDepth
        / (PvNode ? dbParams.queryPVIterPerPlyIncrement : dbParams.queryNonPVIterPerPlyIncrement);
    int queryPly = dbParams.queryPly + queryPlyIncrement;

    if (ss->skipMove           // Skip query in singular extension
        || ss->ply > queryPly  // Only query in the first plies to avoid large speed loss
        || !dbClient.query(board, Rule, db.record))
        return std::nullopt;

    db.hit        = true;
    db.value      = storedValueToSearchValue(db.record.value, ss->ply);
    db.bound      = db.record.bound();
    db.checkChild = ss->ply < queryPly;

    bool tryCut = true;
    switch (db.record.label) {
    case Database::LABEL_NULL: tryCut = false; break;
    case Database::LABEL_BLOCKMOVE:  // Block this move
        return -VALUE_BLOCKED;
    case Database::LABEL_WIN:  // Win for opponent, loss for self
        db.value = std::min(db.value, VALUE_MATED_FROM_DATABASE);
        if (db.bound != BOUND_EXACT)
            db.bound = BOUND_UPPER;
        db.labelBound = BOUND_UPPER;
        break;
    case Database::LABEL_LOSE:  // Loss for opponent, win for self
        db.value = std::max(db.value, VALUE_MATE_FROM_DATABASE);
        if (db.bound != BOUND_EXACT)
            db.bound = BOUND_LOWER;
        db.labelBound = BOUND_LOWER;
        break;
    case Database::LABEL_DRAW:  // Draw for both side
        db.value      = getDrawValue(board, options, ss->ply);
        db.bound      = BOUND_EXACT;
        db.labelBound = BOUND_EXACT;
        break;
    default:  // Read depth, bound, value
        break;
    }

    if (tryCut && !RootNode) {
        int  dbDepth = db.record.depth() + dbParams.queryResultDepthBoundBias;
        bool dbCut   = dbDepth > depth
                     && (db.value >= beta ? (db.bound & BOUND_LOWER) : (db.bound & BOUND_UPPER));
        if (!PvNode && dbCut || db.labelBound == BOUND_LOWER && db.value >= beta  // Win-score-cut
            || db.labelBound == BOUND_UPPER && db.value <= alpha                  // Loss-score-cut
            || db.labelBound == BOUND_EXACT                                       // Draw-score-cut
        ) {
            TT.store(posKey,
                     db.value,
                     ss->staticEval,
                     ss->ttPv,
                     db.bound,
                     Pos::NONE,
                     db.labelBound == BOUND_EXACT ? (int)DEPTH_UPPER_BOUND
                                                  : std::min(dbDepth, (int)DEPTH_UPPER_BOUND),
                     ss->ply);
            return db.value;
        }

        // Expand search window for database cut in PvNode
        if (PvNode && (dbCut || db.labelBound != BOUND_NONE))
            alpha = -VALUE_INFINITE, beta = VALUE_INFINITE;
    }

    return std::nullopt;
}

/// Step 20 of search<Rule,NT>: write the search result into the database.
template <Rule Rule, NodeType NT>
void writeDatabaseRecord(Board              &board,
                         SearchStack        *ss,
                         Depth               depth,
                         Value               bestValue,
                         Bound               bound,
                         const DBProbeState &db)
{
    constexpr bool PvNode   = NT == PV || NT == Root;
    constexpr bool RootNode = NT == Root;

    SearchThread               *thisThread = board.thisThread();
    ABSearchData               *searchData = thisThread->searchDataAs<ABSearchData>();
    SearchOptions              &options    = thisThread->options();
    const DatabaseSearchParams &dbParams   = thisThread->engine.ctx.dbParams;
    Pos                         skipMove   = ss->skipMove;

    if (thisThread->dbClient && !dbParams.readonlyMode  // Never write in database readonly mode
        && !options.balanceMode   // Never write when we are doing balanced search
        && ss->numNullMoves == 0  // Never write when in null move search
        && !(RootNode && (searchData->pvIdx || options.blockMoves.size()))) {
        // A singular-exclusion search skips the (likely best) ttMove, so its
        // bestValue and bound do not describe this position: a fail-low there
        // must not become a determined WIN label. If children wrote records
        // during it, keep the parent chain consistent with a null placeholder
        // (never overwriting an existing record), but do not persist the
        // exclusion result itself.
        if (skipMove) {
            if (ss->dbChildWritten && !db.hit) {
                Database::DBRecord nullRecord {Database::LABEL_NULL, 0, 0};
                thisThread->dbClient->save(board, Rule, nullRecord, dbParams.overwriteRule);
                if (dbParams.mandatoryParentWrite)
                    (ss - 1)->dbChildWritten = true;
            }
            return;
        }

        bool exact  = PvNode && bound == BOUND_EXACT;
        bool isWin  = bestValue > VALUE_MATE_IN_MAX_PLY && (bound & BOUND_LOWER);
        bool isLoss = bestValue < VALUE_MATED_IN_MAX_PLY && (bound & BOUND_UPPER);

        int writePly, writeDepth;
        if (isWin || isLoss) {
            if (ss->ply <= dbParams.mateWritePly
                && mate_step(bestValue, ss->ply) >= dbParams.mateWriteMinStep) {
                writePly = dbParams.mateWritePly;
                writeDepth =
                    exact ? dbParams.mateWriteMinDepthExact : dbParams.mateWriteMinDepthNonExact;
            }
            else
                writePly = -1, writeDepth = MAX_DEPTH;
        }
        else {
            writePly = exact ? dbParams.pvWritePly : dbParams.nonPVWritePly;
            writeDepth =
                exact ? (std::abs(bestValue) <= dbParams.writeValueRange ? dbParams.pvWriteMinDepth
                                                                         : MAX_DEPTH)
                : bound == BOUND_UPPER
                    ? (bestValue <= dbParams.writeValueRange ? dbParams.nonPVWriteMinDepth
                                                             : MAX_DEPTH)
                    : (-bestValue >= dbParams.writeValueRange ? dbParams.nonPVWriteMinDepth
                                                              : MAX_DEPTH);
        }

        if (RootNode
            || ss->dbChildWritten  // Write anyway if we have children that have already written
            || PvNode && ss->ply <= 1 + isLoss
                   && options.multiPV > 1   // Always add new record in multipv
            || ss->ply <= writePly - isWin  // Loss label are recorded one ply less
                   && (db.hit || depth >= writeDepth + isWin)
            || db.hit && (isWin || isLoss)  // Always try overwrite existing record with W/L record
            || PvNode && db.hit             // Try overwrite existing winrate with newer winrate
                   && ss->ply
                          <= (exact ? dbParams.exactOverwritePly : dbParams.nonExactOverwritePly)) {
            // Assume we have already read record from the database
            Database::DBRecord newRecord;

            // Assign determined label if we have a sure win/loss
            // Do not inherit determined label from queried record,
            // only write determined label when we have searched it.
            newRecord.label = isWin    ? Database::LABEL_LOSE  // Loss for opponent
                              : isLoss ? Database::LABEL_WIN   // Win for opponent
                              : db.hit && !Database::isDeterminedLabel(db.record.label)
                                  ? db.record.label
                                  : Database::LABEL_NONE;
            newRecord.value = searchValueToStoredValue(bestValue, ss->ply);
            newRecord.setDepthBound((int)depth, bound);

            // Write if there is no db hit, or the new record satisfy the overwrite rule
            if (!db.hit || Database::checkOverwrite(db.record, newRecord, dbParams.overwriteRule)) {
                thisThread->dbClient->save(board,
                                           Rule,
                                           newRecord,
                                           db.hit ? Database::OverwriteRule::Always
                                                  : dbParams.overwriteRule);
                if (dbParams.mandatoryParentWrite)
                    (ss - 1)->dbChildWritten = true;
            }
        }
    }
}

/// Step 6 of search<Rule,NT>: compute the static evaluation when the opponent
/// has no four/five threat, consulting/updating the TT entry. Sets ss->staticEval.
/// @return Pair of (eval estimation, static eval improvement over two plies).
template <Rule Rule>
std::pair<Value, int> computeStaticEval(Board       &board,
                                        SearchStack *ss,
                                        Value        alpha,
                                        Value        beta,
                                        HashKey      posKey,
                                        Pos          skipMove,
                                        bool         ttHit,
                                        Value        ttValue,
                                        Value        ttEval,
                                        Bound        ttBound)
{
    Value eval;
    if (ttHit) {
        // Never assume anything about values stored in TT
        ss->staticEval = eval = ttEval;
        if (eval == VALUE_NONE)
            ss->staticEval = eval = Evaluation::evaluate<Rule>(board, alpha, beta);

        // Try to use ttValue as a better eval estimation
        if (ttValue != VALUE_NONE && (ttBound & (ttValue > eval ? BOUND_LOWER : BOUND_UPPER)))
            eval = ttValue;
    }
    else {
        ss->staticEval = eval = Evaluation::evaluate<Rule>(board, alpha, beta);

        // Save static evaluation into transposition table
        if (!skipMove)
            TT.store(posKey,
                     VALUE_NONE,
                     ss->staticEval,
                     ss->ttPv,
                     BOUND_NONE,
                     Pos::NONE,
                     (int)DEPTH_NONE,
                     ss->ply);
    }

    return {eval, ss->staticEval - (ss - 2)->staticEval};
}

/// Compute a complexity metric of the position from both sides' pattern4 counts.
inline float positionComplexity(const Board &board, Color self, Color oppo)
{
    uint16_t complexCount = 1;
    for (int pat4 = L_FLEX2; pat4 <= D_BLOCK4_PLUS; pat4++) {
        complexCount += board.p4Count(self, (Pattern4)pat4);
        complexCount += board.p4Count(oppo, (Pattern4)pat4);
    }
    return ::logf(complexCount);
}

/// Heuristic classification of the move about to be searched, consumed by the
/// pruning (step 12), extension (step 13) and reduction (step 15) heuristics.
struct MoveTraits
{
    bool important;  // self J_FLEX2_2X+ / oppo H_FLEX3+ / renju false-forbidden
    bool trivial;    // no pattern for either side
    bool distract;   // far from both our own and the opponent's last moves
    int  distSelf;   // distance to our own move two plies ago
    int  distOppo;   // distance to the opponent's last move
};

/// Classify the move about to be searched. Requires ss->moveP4 to be set.
template <Rule Rule>
MoveTraits classifyMove(SearchStack *ss, Pos move, Color self, Color oppo)
{
    MoveTraits mt;
    // False forbidden move in Renju is considered as important move
    mt.important = ss->moveP4[self] >= J_FLEX2_2X || ss->moveP4[oppo] >= H_FLEX3
                   || (Rule == Rule::RENJU && ss->moveP4[BLACK] == FORBID);
    mt.trivial  = ss->moveP4[BLACK] == NONE && ss->moveP4[WHITE] == NONE;
    mt.distOppo = Pos::distance(move, (ss - 1)->currentMove);
    mt.distSelf = Pos::distance(move, (ss - 2)->currentMove);
    mt.distract = mt.distSelf > (Rule == RENJU ? 5 : 4) && mt.distOppo > 4;
    return mt;
}

/// Step 15 of search<Rule,NT>: compute the LMR reduction for the current move.
/// Also updates ss->statScore. Called after the move has been made on board, so
/// the node's move/self/oppo must be passed in rather than derived from board.
template <Rule Rule, NodeType NT>
Depth computeLmrReduction(Board            &board,
                          SearchStack      *ss,
                          const MovePicker &mp,
                          Pos               move,
                          Color             self,
                          Color             oppo,
                          Depth             depth,
                          int               moveCount,
                          int               improvement,
                          Value             alpha,
                          Value             beta,
                          Value             bestValue,
                          bool              cutNode,
                          bool              oppo4,
                          float             complexity,
                          const MoveTraits &mt)
{
    constexpr bool PvNode   = NT == PV || NT == Root;
    constexpr bool RootNode = NT == Root;

    SearchThread *thisThread = board.thisThread();
    ABSearchData *searchData = thisThread->searchDataAs<ABSearchData>();
    ABSearcher   *searcher   = static_cast<ABSearcher *>(thisThread->engine.searcher());

    Depth r = reduction<Rule, PvNode>(searcher->reductions,
                                      depth,
                                      moveCount,
                                      improvement,
                                      beta - alpha,
                                      searchData->rootDelta);

    // Policy based reduction (~59 elo)
    if (mp.hasPolicyScore())
        r += policyReduction<Rule>(mp.curMoveScore()
                                   * (0.1f / Evaluation::PolicyBuffer::ScoreScale));

    // Dynamic reduction based on complexity (~2 elo)
    r += complexity * complexityReduction<Rule>(mt.trivial, mt.important, mt.distract);

    // Decrease reduction if position is or has been on the PV (~10 elo)
    if (ss->ttPv)
        r -= LMRTtPvSubtract[Rule];

    // Increase reduction for nodes that does not improve root alpha (~0 elo)
    if (!RootNode && (ss->ply & 1) && bestValue >= -searchData->rootAlpha)
        r += LMRNoAlphaAdd[Rule];

    // Increase reduction for cut nodes if is not killer moves (~5 elo)
    if (cutNode && !(!oppo4 && ss->isKiller(move) && ss->moveP4[self] < H_FLEX3))
        r += LMRNoKillerCutNodeAdd[Rule];

    // Increase reduction for useless defend move (~6 elo)
    if (oppo4 && ss->moveP4[oppo] < E_BLOCK4) {
        r += (mt.distOppo > 4 ? OPPO_USELESS_DEFEND_REDUCTION : 0);
        r += (mt.distSelf > 4 ? SELF_USELESS_DEFEND_REDUCTION : 0);
    }

    // Decrease reduction for continuous attack (~5 elo)
    if (!oppo4 && (ss - 2)->moveP4[self] >= H_FLEX3
        && (ss->moveP4[self] >= H_FLEX3 || mt.distSelf <= 4 && ss->moveP4[self] >= J_FLEX2_2X))
        r -= CONTINUOUS_ATTACK_EXT;

    if constexpr (Rule == Rule::RENJU) {
        // Decrease reduction for false forbidden move in Renju (~6 elo)
        if (ss->moveP4[BLACK] == FORBID)
            r -= FALSE_FORBID_LESS_REDUCTION;
    }

    // Update statScore of this node
    ss->statScore = statScore(searchData->mainHistory, self, move);

    // Decrease/increase reduction for moves with a good/bad history (~9 elo)
    r -= extensionFromStatScore<Rule>(ss->statScore, depth);

    return r;
}

/// Root part of step 18 of search<Rule,NT>: update the RootMove entry for the
/// searched move, counting bestmove changes and non-mated root moves.
/// @return The (possibly balance-adjusted) value used for best-move comparison.
Value updateRootMove(Board       &board,
                     SearchStack *ss,
                     Pos          move,
                     Value        value,
                     Value        alpha,
                     int          moveCount,
                     uint64_t     curNumNodes,
                     int         &nonMatedCount)
{
    SearchThread  *thisThread = board.thisThread();
    ABSearchData  *searchData = thisThread->searchDataAs<ABSearchData>();
    SearchOptions &options    = thisThread->options();

    const bool balance2  = options.balanceMode == SearchOptions::BALANCE_TWO;
    Value      moveValue = value;
    RootMove  &rm =
        balance2
             ? thisThread
                  ->rootMoves[thisThread->balance2Moves[Balance2Move {board.getLastMove(), move}]]
             : *std::find(thisThread->rootMoves.begin(), thisThread->rootMoves.end(), move);

    // If we are in balance move mode, map the original move value to its negative
    // absolute value, which makes best move and PV selection based on how balanced
    // a move is rather than how good a move is. Note that move value recorded in
    // RootMove is kept unchanged for better eval output.
    if (options.balanceMode)
        value = balancedValue(value, options.balanceBias);

    // Check for PV move or new best move.
    rm.numNodes += thisThread->numNodes.load(std::memory_order_relaxed) - curNumNodes;
    rm.selDepth = thisThread->selDepth;
    if (moveCount == 1 || value > alpha) {
        rm.value = moveValue;
        rm.pv.resize(1 + balance2);

        assert((ss + 1)->pv);

        for (Pos *m = (ss + 1)->pv; *m != Pos::NONE; m++)
            rm.pv.push_back(*m);

        assert(!balance2 || rm.pv.size() >= 2);

        // We record how often the best move has been changed in each iteration.
        // When the best move changes frequently, we allocate some more time.
        if (moveCount > 1)
            searchData->bestMoveChanges++;
    }
    else {
        // All other moves but PV are set to the lowest value: this is not a problem as
        // the sort is stable and its rank in rootmoves is kept, just the PV is pushed up.
        rm.value = VALUE_NONE;
    }

    // We record how many moves is not mated at root, which can indicate singular root.
    if (value > VALUE_MATED_IN_MAX_PLY)
        nonMatedCount++;

    return value;
}

/// The main search function for both PV and non-PV nodes
template <Rule Rule, NodeType NT>
Value search(Board &board, SearchStack *ss, Value alpha, Value beta, Depth depth, bool cutNode)
{
    constexpr bool PvNode   = NT == PV || NT == Root;
    constexpr bool RootNode = NT == Root;

    // Do some sanity check over input arguments
    assert(-VALUE_INFINITE <= alpha && alpha < beta && beta <= VALUE_INFINITE);
    assert(PvNode || (alpha == beta - 1));
    assert(DEPTH_LOWER_BOUND <= depth && depth < DEPTH_UPPER_BOUND);
    assert(!(PvNode && cutNode));
    assert(0 <= ss->ply && ss->ply < MAX_PLY);

    // Step 1. Initialize node
    SearchThread  *thisThread = board.thisThread();
    ABSearchData  *searchData = thisThread->searchDataAs<ABSearchData>();
    SearchOptions &options    = thisThread->options();
#ifdef POLICY_TRAINING
    const bool     policyTraceEnabled    = thisThread->engine.policyTraceSession() != nullptr;
    const uint64_t policyTraceNodeStart  = thisThread->numNodes.load(std::memory_order_relaxed);
    const Time     policyTraceEventStart = policyTraceEnabled ? now() : Time(0);
#endif
    thisThread->numNodes.fetch_add(1, std::memory_order_relaxed);

    Color    self = board.sideToMove(), oppo = ~self;
    uint16_t oppo5 = board.p4Count(oppo, A_FIVE);           // opponent five
    uint16_t oppo4 = oppo5 + board.p4Count(oppo, B_FLEX4);  // opponent straight four and five

    // Dive into vcf search when the depth reaches zero (~17 elo)
    if (depth <= 0.0f) {
        return oppo5 ? vcfdefend<Rule, NT>(board, ss, alpha, beta)
                     : vcfsearch<Rule, NT>(board, ss, alpha, beta);
    }

    int            moveCount = 0, nonMatedCount = 0;
    Value          bestValue = -VALUE_INFINITE, value;
    Pos            bestMove = Pos::NONE;
    HistoryTracker histTracker(board, ss);

    // Update selDepth (selDepth counts from 1, ply from 0)
    if (PvNode && thisThread->selDepth <= ss->ply)
        thisThread->selDepth = ss->ply + 1;

    if (!RootNode) {
        // Step 2. Check for aborted search and immediate draw
        // Check if we reach the time limit
        if (thisThread->isMainThread())
            thisThread->engine.ctx.checkExit();

        // Check if the board has been filled or we have reached the max game ply.
        if (board.movesLeft() == 0 || board.nonPassMoveCount() >= options.maxMoves)
            return getDrawValue(board, options, ss->ply);

        // Check if we have reached the max ply
        if (ss->ply >= MAX_PLY)
            return Evaluation::evaluate<Rule>(board, alpha, beta);

        // Check for immediate winning
        if ((value = quickWinCheck<Rule>(board, ss->ply, beta)) != VALUE_ZERO) {
            // Do not return mate that longer than maxMoves option
            if (board.nonPassMoveCount() + mate_step(value, ss->ply) > options.maxMoves)
                value = getDrawValue(board, options, ss->ply);

            return value;
        }

        // Step 3. Mate distance pruning.
        alpha = std::max(mated_in(ss->ply), alpha);
        beta  = std::min(mate_in(ss->ply + 1), beta);
        if (alpha >= beta)
            return alpha;

        // Initialize statScore to zero for the grandchildren of the current position.
        // So statScore is shared between all grandchildren and only the first grandchild
        // starts with statScore = 0. Later grandchildren start with the last calculated
        // statScore of the previous grandchild.
        (ss + 2)->statScore = 0;

        // Pass current number of null moves to next ply
        (ss + 1)->numNullMoves = ss->numNullMoves;
    }
    else
        searchData->rootDelta = beta - alpha;

    // Step 4. Transposition table lookup.
    // Use a different hash key in case of an skip move to avoid overriding full search result.
    Pos     skipMove = ss->skipMove;
    HashKey posKey   = board.zobristKey() ^ (skipMove ? Hash::LCHash(skipMove) : 0);
    Value   ttValue  = VALUE_NONE;
    Value   ttEval   = VALUE_NONE;
    bool    ttIsPv   = false;
    Bound   ttBound  = BOUND_NONE;
    Pos     ttMove   = Pos::NONE;
    int     ttDepth  = 0;
    bool    ttHit    = TT.probe(posKey, ttValue, ttEval, ttIsPv, ttBound, ttMove, ttDepth, ss->ply);
    // At the root, seed ttMove with the PV line currently being searched:
    // earlier lines are excluded from this line's move loop, so rootMoves[0]
    // would name a move that is guaranteed to be skipped in MultiPV mode.
    if (RootNode && searchData->completedDepth.load(std::memory_order_relaxed))
        ttMove = thisThread->rootMoves[searchData->pvIdx]
                     .pv[options.balanceMode == SearchOptions::BALANCE_TWO];
    if (!skipMove)
        ss->ttPv = PvNode || ttHit && ttIsPv;
    (ss + 1)->ttPv = false;

    // At non-PV nodes we check for an early TT cutoff
    if (!PvNode && ttHit && ttDepth >= depth
        && (ttBound & (ttValue >= beta ? BOUND_LOWER : BOUND_UPPER))) {
        // Update move heuristics for ttMove
        histTracker.updateTTMoveStats(depth, ttMove, ttValue, beta);
        return ttValue;
    }

    // Step 5. Database query
    DBProbeState db;
    if (auto dbCutValue = probeDatabaseAtNode<Rule, NT>(board, ss, alpha, beta, depth, posKey, db))
        return *dbCutValue;

    // Step 6. Static evaluation
    Value eval        = VALUE_NONE;
    int   improvement = 0;  // Static eval change in the last two ply

    // Reset killer of grand-children
    (ss + 2)->killers[0] = Pos::NONE;
    (ss + 2)->killers[1] = Pos::NONE;

    if (oppo4) {
        // Use static evaluation from previous ply if opponent makes a four/five attack
        ss->staticEval = -(ss - 1)->staticEval;

        // Skip early pruning when we only have one possible move
        if (oppo5)
            goto moves_loop;
    }
    else if (!RootNode) {
        std::tie(eval, improvement) = computeStaticEval<
            Rule>(board, ss, alpha, beta, posKey, skipMove, ttHit, ttValue, ttEval, ttBound);
    }

    // Step 7. Razoring with VCF (~68 elo)
    if (!PvNode
        && (alpha < VALUE_MATE_IN_MAX_PLY || !ttHit)  // We are not searching for a short win
        && eval + razorMargin<Rule>(depth) < alpha) {
        return vcfsearch<Rule, NonPV>(board, ss, alpha, alpha + 1);
    }

    // Step 8. Futility pruning: child node (~121 elo)
    if (!PvNode && eval < VALUE_MATE_IN_MAX_PLY  // Do not return unproven wins
        && beta > VALUE_MATED_IN_MAX_PLY         // Confirm non-losing move exists
        && eval - futilityMargin<Rule>(depth - 1, cutNode && !ttHit, improvement > 0) >= beta
        && !((ss - 2)->moveP4[self] >= E_BLOCK4 && (ss - 4)->moveP4[self] >= E_BLOCK4))
        return eval;

    // Step 9. Null move pruning (~3 elo)
    if (!PvNode && !oppo4 && !skipMove && eval >= beta
        && board.getLastMove() != Pos::PASS  // No consecutive pass moves
        && ss->staticEval >= beta + nullMoveMargin<Rule>(depth)) {
        Depth r         = nullMoveReduction<Rule>(depth);
        ss->currentMove = Pos::PASS;

        (ss + 1)->numNullMoves++;
        TT.prefetch(board.zobristKeyAfter(Pos::PASS));  // pre-make: see Step 14
        board.move<Rule>(Pos::PASS);
        value = -search<Rule, NonPV>(board, ss + 1, -beta, -beta + 1, depth - r, !cutNode);
        board.undo<Rule>();
        (ss + 1)->numNullMoves--;

        if (value >= beta) {
            // Do not return unproven mate scores
            if (value >= VALUE_MATE_IN_MAX_PLY)
                value = beta;

            if (std::abs(beta) < VALUE_MATE_IN_MAX_PLY)
                return value;
            else {
                // Do verification search at high depths, with null move pruning disabled.
                // An all-blocked sentinel from this same-frame call carries no real
                // score and must not confirm the cutoff.
                Value v = search<Rule, NonPV>(board, ss, beta - 1, beta, depth - r, false);
                if (v >= beta && v != -VALUE_BLOCKED)
                    return value;
            }
        }
    }

    // Step 10. Internal iterative reduction (~3 elo)
    if (!RootNode && PvNode && !ttMove)
        depth -= IIR_REDUCTION_PV[Rule];

    // Reduce for pv ttMove that has not been chosen for a few iterations (~32 elo)
    if (PvNode && depth > 1 && ttMove)
        depth -= std::clamp((depth - ttDepth) * IIR_REDUCTION_TT[Rule],
                            0.0f,
                            IIR_REDUCTION_TT_MAX[Rule]);

    // Drop to vcfsearch if depth is below zero
    if (depth <= 0)
        return vcfsearch<Rule, NT>(board, ss, alpha, beta);

    // Internal iterative deepening on higher depth (~1 elo)
    if (depth >= IID_DEPTH && !ttMove) {
        depth -= IIR_REDUCTION[Rule];

        // We only need best move from the iid search, so we just discard its result
        search<Rule, NT>(board, ss, alpha, beta, depth - iidDepthReduction<Rule>(depth), cutNode);

        // Get best move from transposition table, which should be just written by the search.
        Value tmpEval;
        bool  tmpIsPv;
        Bound tmpBound;
        int   tmpDepth;
        ttHit = TT.probe(posKey, ttValue, tmpEval, tmpIsPv, tmpBound, ttMove, tmpDepth, ss->ply);
    }

    // When opponent is doing A_FIVE attack, search starts from here
moves_loop:
    SearchContext &ctx         = thisThread->engine.ctx;
    uint64_t       curNumNodes = 0;
    ss->dbChildWritten         = false;

    // Calculate a complexity metric for current position
    float complexity = positionComplexity(board, self, oppo);

    // Fail-High reduction (~50 elo)
    // Indicate cutNode that will probably fail high if current eval is far above beta
    bool likelyFailHigh = !PvNode && cutNode && eval >= beta + failHighMargin<Rule>(depth, oppo4);

#ifdef POLICY_TRAINING
    const Value         policyTraceAlpha = alpha;
    const Value         policyTraceBeta  = beta;
    const Depth         policyTraceDepth = depth;
    DeferredPolicyTrace deferredPolicyTrace;
    bool                policyTraceInitialized = false;
#endif
    MovePicker mp(Rule,
                  board,
                  MovePicker::ExtraArgs<MovePicker::MAIN> {
                      ttMove,
                      makeMoveHistoryScoring(Rule,
                                             board.sideToMove(),
                                             searchData->mainHistory,
                                             searchData->counterMoveHistory),
                  });

    // Step 11. Loop through all legal moves until no moves remain
    // or a beta cutoff occurs.
    while (Pos move = mp()) {
#ifdef POLICY_TRAINING
        initializePolicyTraceEvent<NT>(mp,
                                       ss,
                                       policyTraceAlpha,
                                       policyTraceBeta,
                                       policyTraceDepth,
                                       cutNode,
                                       deferredPolicyTrace,
                                       policyTraceInitialized);
        Tuning::PolicyTraceCandidate *policyTraceCandidate = mp.policyTraceCandidate(move);
#endif
        assert(board.isLegal(move));

        // Skip excluded move when in Singular extension search
        if (!RootNode && move == skipMove) {
#ifdef POLICY_TRAINING
            if (policyTraceCandidate) {
                policyTraceCandidate->filter = Tuning::PolicyTraceFilter::SingularExcluded;
                policyTraceCandidate->disposition =
                    Tuning::PolicyTraceDisposition::SingularExcluded;
            }
            else if (move == ttMove) {
                deferredPolicyTrace.move        = move;
                deferredPolicyTrace.filter      = Tuning::PolicyTraceFilter::SingularExcluded;
                deferredPolicyTrace.disposition =
                    Tuning::PolicyTraceDisposition::SingularExcluded;
                deferredPolicyTrace.valid = true;
            }
#endif
            continue;
        }

        if (RootNode) {
            if (options.balanceMode == SearchOptions::BALANCE_TWO) {
                Balance2Move b2move {board.getLastMove(), move};

                // Skip balance move pair not listed in Root Move List
                if (thisThread->balance2Moves.find(b2move) == thisThread->balance2Moves.end()) {
#ifdef POLICY_TRAINING
                    if (policyTraceCandidate) {
                        policyTraceCandidate->filter = Tuning::PolicyTraceFilter::RootExcluded;
                        policyTraceCandidate->disposition =
                            Tuning::PolicyTraceDisposition::Filtered;
                    }
                    else if (move == ttMove) {
                        deferredPolicyTrace.move        = move;
                        deferredPolicyTrace.filter      = Tuning::PolicyTraceFilter::RootExcluded;
                        deferredPolicyTrace.disposition =
                            Tuning::PolicyTraceDisposition::Filtered;
                        deferredPolicyTrace.valid = true;
                    }
#endif
                    continue;
                }

                // Skip moves not in root move list and PV moves that have been already searched
                if (std::count(thisThread->rootMoves.begin(),
                               thisThread->rootMoves.begin() + searchData->pvIdx,
                               b2move)) {
#ifdef POLICY_TRAINING
                    if (policyTraceCandidate) {
                        policyTraceCandidate->filter = Tuning::PolicyTraceFilter::RootExcluded;
                        policyTraceCandidate->disposition =
                            Tuning::PolicyTraceDisposition::Filtered;
                    }
                    else if (move == ttMove) {
                        deferredPolicyTrace.move        = move;
                        deferredPolicyTrace.filter      = Tuning::PolicyTraceFilter::RootExcluded;
                        deferredPolicyTrace.disposition =
                            Tuning::PolicyTraceDisposition::Filtered;
                        deferredPolicyTrace.valid = true;
                    }
#endif
                    continue;
                }

                // Restore previous movecount from stack
                if (!moveCount)
                    moveCount = ss->moveCount;

                // Prevent moveCount overflow in reduction()
                moveCount = std::min(moveCount, MAX_MOVES - 1);
            }
            // Skip moves not in root move list and PV moves that have been already searched
            else if (!std::count(thisThread->rootMoves.begin() + searchData->pvIdx,
                                 thisThread->rootMoves.end(),
                                 move)) {
#ifdef POLICY_TRAINING
                if (policyTraceCandidate) {
                    policyTraceCandidate->filter      = Tuning::PolicyTraceFilter::RootExcluded;
                    policyTraceCandidate->disposition = Tuning::PolicyTraceDisposition::Filtered;
                }
                else if (move == ttMove) {
                    deferredPolicyTrace.move        = move;
                    deferredPolicyTrace.filter      = Tuning::PolicyTraceFilter::RootExcluded;
                    deferredPolicyTrace.disposition =
                        Tuning::PolicyTraceDisposition::Filtered;
                    deferredPolicyTrace.valid = true;
                }
#endif
                continue;
            }

            curNumNodes = thisThread->numNodes.load(std::memory_order_relaxed);
        }

        if (RootNode && thisThread->isMainThread())
            ctx.printer.printEnteringMove(*thisThread,
                                          ctx.timectl,
                                          searchData->pvIdx,
                                          searchData->rootDepth,
                                          move);

        // Initialize heuristic information
        ss->moveCount     = ++moveCount;
        ss->moveP4[BLACK] = board.pattern4(move, BLACK);
        ss->moveP4[WHITE] = board.pattern4(move, WHITE);
#ifdef POLICY_TRAINING
        DeferredPolicyTrace currentPolicyTrace;
        currentPolicyTrace.move        = move;
        currentPolicyTrace.filter      =
            move == ttMove ? Tuning::PolicyTraceFilter::TtMove
                           : Tuning::PolicyTraceFilter::None;
        currentPolicyTrace.alphaBefore = alpha;
        currentPolicyTrace.moveCount   = static_cast<uint16_t>(moveCount);
        currentPolicyTrace.valid       = true;
        if (!policyTraceCandidate && move == ttMove)
            deferredPolicyTrace = currentPolicyTrace;
#endif

        const MoveTraits mt = classifyMove<Rule>(ss, move, self, oppo);

        // Step 12. Pruning at shallow depth
        // Do pruning only when we have non-losing moves, otherwise we may have a false mate.
        // Also skip pruning if there might be a child database record we want to read.
        if (!RootNode && !db.checkChild && bestValue > VALUE_MATED_IN_MAX_PLY) {
            // Move count pruning: skip move if movecount is above threshold (~107 elo)
            if (moveCount >= futilityMoveCount(depth, improvement > 0)) {
#ifdef POLICY_TRAINING
                currentPolicyTrace.disposition = Tuning::PolicyTraceDisposition::MoveCountPruned;
                if (policyTraceCandidate)
                    applyDeferredPolicyTrace(*policyTraceCandidate, currentPolicyTrace);
                else
                    deferredPolicyTrace = currentPolicyTrace;
#endif
                continue;
            }

            // Skip trivial moves at lower depth (~2 elo at LTC)
            if (mt.trivial && depth < TRIVIAL_PRUN_DEPTH) {
#ifdef POLICY_TRAINING
                currentPolicyTrace.disposition = Tuning::PolicyTraceDisposition::TrivialPruned;
                if (policyTraceCandidate)
                    applyDeferredPolicyTrace(*policyTraceCandidate, currentPolicyTrace);
                else
                    deferredPolicyTrace = currentPolicyTrace;
#endif
                continue;
            }

            // Policy based pruning (~10 elo)
            if (mp.hasPolicyScore() && mp.curMoveScore() < policyPruningScore<Rule>(depth)) {
#ifdef POLICY_TRAINING
                currentPolicyTrace.disposition = Tuning::PolicyTraceDisposition::PolicyPruned;
                if (policyTraceCandidate)
                    applyDeferredPolicyTrace(*policyTraceCandidate, currentPolicyTrace);
                else
                    deferredPolicyTrace = currentPolicyTrace;
#endif
                continue;
            }

            // Prun distract defence move which is likely to delay a winning (~2 elo)
            if (oppo4 && depth < TRIVIAL_PRUN_DEPTH && ss->moveP4[oppo] < E_BLOCK4 && mt.distract) {
#ifdef POLICY_TRAINING
                currentPolicyTrace.disposition =
                    Tuning::PolicyTraceDisposition::DistractDefensePruned;
                if (policyTraceCandidate)
                    applyDeferredPolicyTrace(*policyTraceCandidate, currentPolicyTrace);
                else
                    deferredPolicyTrace = currentPolicyTrace;
#endif
                continue;
            }
        }

        // Step 13. Extensions
        Depth extension = 0;

        // Singular response extension for opponent B4 attack (~77 elo)
        if (oppo5)
            extension = OPPO5_EXT;

        // Singular extension: only one move fails high while other moves fails low on a search of
        // (alpha-s, beta-s), then this move is singular and should be extended. (~52 elo)
        else if (!RootNode && depth >= SE_DEPTH && move == ttMove
                 && !skipMove                                  // No recursive singular search
                 && std::abs(ttValue) < VALUE_MATE_IN_MAX_PLY  // ttmove value is not a mate
                 && (ttBound & BOUND_LOWER)                    // ttMove failed high last time
                 && ttDepth >= depth - SE_TTE_DEPTH[Rule]      // ttEntry has enough depth to trust
        ) {
            bool  formerPv = !PvNode && ss->ttPv;
            Value singularBeta =
                std::max(ttValue - singularMargin<Rule>(depth, formerPv), -VALUE_MATE);

            // Exclude ttMove from the reduced depth search to see the value of second best move
            ss->skipMove = move;
            value        = search<Rule, NonPV>(board,
                                        ss,
                                        singularBeta - 1,
                                        singularBeta,
                                        depth - singularReduction(depth, formerPv),
                                        cutNode);
            ss->skipMove = Pos::NONE;

            // Every non-ttMove alternative was blocked by database records: the
            // exclusion search produced no real score, so treat the ttMove as
            // singular (nothing else is playable) rather than as a multi-cut.
            if (value == -VALUE_BLOCKED)
                value = singularBeta - 1;

            // Extend if only the ttMove fails high, while other moves fails low.
            if (value < singularBeta) {
                // Extend two ply if current non-pv position is highly singular.
                if (!PvNode && value < singularBeta - doubleSEMargin<Rule>(depth)
                    && ss->extraExtension < SE_EXTRA_MAX_DEPTH)
                    extension = 2.0f;
                else
                    extension = 1.0f;
            }
            // Multi-cut pruning: we also failed high on a reduced search without ttMove.
            else if (singularBeta >= beta)
                return beta;
            // Reduce if we are likely to fail high.
            else if (ttValue >= beta)
                extension = -SE_REDUCTION_FH;
        }

        // Extension for ttmove without singular extension (~12 elo)
        else if (move == ttMove) {
            // Extension for ttmove
            extension = PvNode ? TTM_EXT_PV[Rule] : TTM_EXT_NONPV[Rule];

            // Additional extension for near B4 ttmove
            if (ss->moveP4[self] >= E_BLOCK4 && mt.distSelf <= 6)
                extension += (mt.distSelf <= 4 ? NEARB4_EXT_DIST4 : NEARB4_EXT_DIST6);
        }

        // Fail high reduction (~8 elo)
        if (likelyFailHigh) {
            if (ss->moveP4[self] >= E_BLOCK4) {
                // If we failed high for two continous E_BLOCK4 moves, extend rather than reduce
                if ((ss - 2)->moveP4[self] >= E_BLOCK4)
                    extension += 1.0f;
            }
            else
                extension -= 1.0f;
        }

        // Calculate new depth for this move
        Depth newDepth     = depth - 1.0f + extension;
        ss->currentMove    = move;
        ss->extraExtension = (ss - 1)->extraExtension + std::max(extension - 1.0f, 0.0f);
#ifdef POLICY_TRAINING
        const uint64_t policyTraceMoveStart = thisThread->numNodes.load(std::memory_order_relaxed);
        currentPolicyTrace.plannedReduction = 0;
#endif

        // Step 14. Make the move
        // Prefetch the child's TT line before the board update, so the memory access
        // overlaps the whole pattern walk instead of starting after it.
        [[maybe_unused]] HashKey childKey = board.zobristKeyAfter(move);
        TT.prefetch(childKey);
        board.move<Rule>(move);
        assert(board.zobristKey() == childKey);

        // Step 15. Late move reduction (LMR). Moves are searched with a reduced
        // depth and will be re-searched at full depth if fail high.
        if (depth >= 2 && moveCount > 1 + RootNode) {
            Depth r = computeLmrReduction<Rule, NT>(board,
                                                    ss,
                                                    mp,
                                                    move,
                                                    self,
                                                    oppo,
                                                    depth,
                                                    moveCount,
                                                    improvement,
                                                    alpha,
                                                    beta,
                                                    bestValue,
                                                    cutNode,
                                                    oppo4,
                                                    complexity,
                                                    mt);

            // Allow LMR to do deeper search in some circumstances
            // Clamp the LMR depth to newDepth (no depth less than one)
            Depth d = std::max(std::min(newDepth - r, newDepth + 1), 1.0f);
#ifdef POLICY_TRAINING
            currentPolicyTrace.plannedReduction = r;
            recordPolicyTraceSearch(currentPolicyTrace, d);
#endif

            value = -search<Rule, NonPV>(board, ss + 1, -(alpha + 1), -alpha, d, true);

            if (value > alpha && d < newDepth) {
                // Extra extension in lmr (~13 elo)
                Depth ext = lmrExtension<Rule>(newDepth, d, value, alpha, bestValue);
                // Do not allow more extension if extra extension is already high
                if (ss->extraExtension >= LMR_EXTRA_MAX_DEPTH)
                    ext = std::min(ext, 1.0f);
                else
                    ss->extraExtension += std::max(ext - 1.0f, 0.0f);
                newDepth += ext;

                if (d < newDepth) {
#ifdef POLICY_TRAINING
                    recordPolicyTraceSearch(currentPolicyTrace, newDepth);
#endif
                    value = -search<Rule, NonPV>(board,
                                                 ss + 1,
                                                 -(alpha + 1),
                                                 -alpha,
                                                 newDepth,
                                                 !cutNode);
                }
            }
        }

        // Step 16. Full depth search when LMR is skipped or fails high
        else if (!PvNode || moveCount > 1) {
            // If expected reduction is high, we reduce search depth by 1 here
#ifdef POLICY_TRAINING
            recordPolicyTraceSearch(currentPolicyTrace, newDepth);
#endif
            value = -search<Rule, NonPV>(board, ss + 1, -(alpha + 1), -alpha, newDepth, !cutNode);
        }

        // For balance move mode, we also check if a move can trigger beta cut
        // (which is too good to be balanced), so we can safely discard this move.
        if (RootNode && options.balanceMode && moveCount > 1 && value > alpha) {
#ifdef POLICY_TRAINING
            recordPolicyTraceSearch(currentPolicyTrace, newDepth);
#endif
            value = -search<Rule, NonPV>(board, ss + 1, -beta, -(beta - 1), newDepth, !cutNode);
        }

        // For PV nodes only, do a full PV search on the first move or after a fail
        // high (in the latter case search only if value < beta), otherwise let the
        // parent node fail low with value <= alpha and try another move.
        if (PvNode
            && (moveCount == 1
                || (RootNode && options.balanceMode
                        ? balancedValue(value, options.balanceBias) > alpha
                        : value > alpha && (RootNode || value < beta)))) {
#ifdef POLICY_TRAINING
            recordPolicyTraceSearch(currentPolicyTrace, newDepth);
#endif
            (ss + 1)->pv[0]        = Pos::NONE;
            (ss + 1)->dbValueDepth = INT16_MIN;  // Clear database value depth of next move
            value = -search<Rule, PV>(board, ss + 1, -beta, -alpha, newDepth, false);
        }

        // Step 17. Undo move
        board.undo<Rule>();

        if (RootNode && thisThread->isMainThread())
            ctx.printer.printLeavingMove(*thisThread,
                                         ctx.timectl,
                                         searchData->pvIdx,
                                         searchData->rootDepth,
                                         move);

        // Step 18. Check for a new best move
        // Finished searching the move. If a stop occurred, the return value of the search cannot
        // be trusted, so we return immediately without updating best move, PV and TT.
        if (thisThread->engine.isTerminating()) {
            if (thisThread->dbClient
                && !db.hit  // Write when no dbHit, we never overwrite any existing record with null
                && !ctx.dbParams.readonlyMode  // Never write in database readonly mode
                && ss->dbChildWritten  // Write anyway if we have children that have already written
            ) {
                Database::DBRecord newRecord {Database::LABEL_NULL, 0, 0};
                thisThread->dbClient->save(board, Rule, newRecord, ctx.dbParams.overwriteRule);
                (ss - 1)->dbChildWritten = true;
            }
            return VALUE_NONE;
        }
        // This move is blocked from database record
        if (value == VALUE_BLOCKED) {
#ifdef POLICY_TRAINING
            currentPolicyTrace.disposition = Tuning::PolicyTraceDisposition::DatabaseBlocked;
            currentPolicyTrace.nodes =
                thisThread->numNodes.load(std::memory_order_relaxed) - policyTraceMoveStart;
            if (policyTraceCandidate)
                applyDeferredPolicyTrace(*policyTraceCandidate, currentPolicyTrace);
            else
                deferredPolicyTrace = currentPolicyTrace;
#endif
            continue;
        }

        assert(value > -VALUE_INFINITE && value < VALUE_INFINITE);

        if (RootNode)
            value = updateRootMove(board,
                                   ss,
                                   move,
                                   value,
                                   alpha,
                                   moveCount,
                                   curNumNodes,
                                   nonMatedCount);

#ifdef POLICY_TRAINING
        currentPolicyTrace.value = value;
        currentPolicyTrace.bound = value >= beta                             ? BOUND_LOWER
                                   : value <= currentPolicyTrace.alphaBefore ? BOUND_UPPER
                                                                             : BOUND_EXACT;
        currentPolicyTrace.nodes =
            thisThread->numNodes.load(std::memory_order_relaxed) - policyTraceMoveStart;
        currentPolicyTrace.alphaChanged = value > currentPolicyTrace.alphaBefore;
        currentPolicyTrace.disposition =
            value >= beta ? Tuning::PolicyTraceDisposition::SearchedCutoff
            : value > currentPolicyTrace.alphaBefore
                ? Tuning::PolicyTraceDisposition::SearchedAlphaImprovement
                : Tuning::PolicyTraceDisposition::SearchedFailLow;
        if (policyTraceCandidate)
            applyDeferredPolicyTrace(*policyTraceCandidate, currentPolicyTrace);
        else
            deferredPolicyTrace = currentPolicyTrace;
#endif

        // Update best value, best move and PV.
        if (value > bestValue) {
            bestValue = value;

            // Update database value depth of current move
            if (PvNode)
                ss->dbValueDepth = (ss + 1)->dbValueDepth + 1;

            if (value > alpha) {
                bestMove = move;  // Only update best move in pv or fail high node

                if (PvNode && !RootNode)  // Update pv even in fail-high case
                    ss->updatePv(move);

                if (value >= beta) {
                    break;  // Fail high
                }
                else {
                    alpha = value;  // Update alpha, make sure alpha < beta

                    if (RootNode)
                        searchData->rootAlpha = alpha;

                    // Reduce other moves if we have found at least one score improvement (~26 elo)
                    if (depth > 2 && depth < 12 && std::abs(value) < 2000)
                        depth -= ALPHA_IMPROVEMENT_REDUCTION;

                    // If we are in balance move mode, we also shrink beta as to narrow
                    // the search window to [-abs(v-bias)+bias, abs(v-bias)+bias].
                    if (RootNode && options.balanceMode) {
                        assert(alpha <= options.balanceBias);
                        beta = Value(2 * options.balanceBias) - alpha;
                        // Break if search window size reaches zero
                        if (alpha >= beta)
                            break;
                    }
                }
            }
        }

        if (RootNode && thisThread->isMainThread())
            ctx.printer.printMoveResult(*thisThread,
                                        ctx.timectl,
                                        searchData->pvIdx,
                                        searchData->multiPv,
                                        searchData->rootDepth,
                                        move,
                                        value,
                                        bestMove == move);

        // Record good moves that improved alpha bound for move heuristic.
        histTracker.addSearchedMove(move, bestMove);
    }

    // Set singularRoot flag to true if we have only one singular move
    if (RootNode && nonMatedCount == 1 && (moveCount > 1 || thisThread->rootMoves.size() == 1))
        searchData->singularRoot = true;

    // If moves were generated but none produced a value, every one of them
    // was blocked by a database record: propagate the block to the parent
    // instead of treating -VALUE_INFINITE as a searched score (which would
    // poison the TT and could persist a fabricated loss record). The root
    // has no caller that understands the block sentinel, so fall back to a
    // draw score there.
    if (moveCount && bestValue == -VALUE_INFINITE)
        return RootNode ? getDrawValue(board, options, ss->ply) : -VALUE_BLOCKED;

    // Step 19. Check for mate
    // All legal moves have been searched and if there are no legal moves, it must be a mate
    // (in renju). If we are in a singular extension search then return a fail low score.
    if (!moveCount) {
        bestValue = skipMove ? alpha
                             : (board.p4Count(oppo, A_FIVE) ? mated_in(ss->ply + 2)
                                                            : mated_in(ss->ply + 4));

        // Do not return mate that longer than maxMoves option
        if (std::abs(bestValue) >= VALUE_MATE_IN_MAX_PLY) {
            if (board.nonPassMoveCount() + mate_step(bestValue, ss->ply) > options.maxMoves)
                bestValue = getDrawValue(board, options, ss->ply);
        }

        if (RootNode) {
            // All remaining losing root moves are marked with this value
            std::for_each(thisThread->rootMoves.begin() + searchData->pvIdx,
                          thisThread->rootMoves.end(),
                          [=](RootMove &rm) { rm.value = bestValue; });
        }
    }
    // If we have found a best move, update move heuristics
    else if (bestMove)
        histTracker.updateBestmoveStats(depth, bestMove, bestValue);

    // Step 20. Update database record
    Bound bound = bestValue >= beta ? BOUND_LOWER : PvNode && bestMove ? BOUND_EXACT : BOUND_UPPER;
    writeDatabaseRecord<Rule, NT>(board, ss, depth, bestValue, bound, db);

    // Adjust best value with Win/Loss record from database in PV node
    if (!RootNode && PvNode && db.hit) {
        if (db.labelBound == BOUND_LOWER)
            bestValue = std::max(bestValue, db.value);
        else if (db.labelBound == BOUND_UPPER)
            bestValue = std::min(bestValue, db.value);
        else if (int dbDepth = db.record.depth() + ctx.dbParams.queryResultDepthBoundBias;
                 (db.bound == BOUND_EXACT                           // Exact-cut
                  || db.bound == BOUND_LOWER && db.value >= beta    // Beta-cut
                  || db.bound == BOUND_UPPER && db.value <= alpha)  // Alpha-cut
                 && dbDepth > std::max((int)std::ceil(depth), ss->dbValueDepth)
                 && db.value > bestValue - (dbDepth - (int)std::ceil(depth)) * 10)
            bestValue = db.value, bound = db.bound, ss->dbValueDepth = dbDepth;
    }

#ifdef POLICY_TRAINING
    initializePolicyTraceEvent<NT>(mp,
                                   ss,
                                   policyTraceAlpha,
                                   policyTraceBeta,
                                   policyTraceDepth,
                                   cutNode,
                                   deferredPolicyTrace,
                                   policyTraceInitialized);
    finishPolicyTraceEvent(mp,
                           *thisThread,
                           policyTraceNodeStart,
                           policyTraceEventStart,
                           bestValue,
                           bestMove,
                           bound);
#endif

    // Step 21. Save TT entry for this position
    // If no good move is found and the previous position was ttPv, then the previous
    // opponent move is probably good and the new position is added to the search tree.
    if (bestValue <= alpha)
        ss->ttPv = ss->ttPv || ((ss - 1)->ttPv && depth > 3);
    // Otherwise, a counter move has been found and if the position is the last leaf
    // in the search tree, remove the position from the search tree.
    else if (depth > 3)
        ss->ttPv = ss->ttPv && (ss + 1)->ttPv;

    // Don't save partial result in singular extension, multi pv at root or balance mode.
    if (!skipMove
        && !(RootNode && (searchData->pvIdx || options.balanceMode || options.blockMoves.size())))
        TT.store(posKey, bestValue, ss->staticEval, ss->ttPv, bound, bestMove, (int)depth, ss->ply);

    assert(bestValue > -VALUE_INFINITE && bestValue < VALUE_INFINITE);
    return bestValue;
}

/// The VCF search function only searches continuous VCF moves to avoid
/// search explosion. It returns the best evaluation in a VCF tree.
template <Rule Rule, NodeType NT>
Value vcfsearch(Board &board, SearchStack *ss, Value alpha, Value beta, Depth depth)
{
    constexpr bool PvNode = NT == PV || NT == Root;

    // Do some sanity check over input arguments
    assert(-VALUE_INFINITE <= alpha && alpha < beta && beta <= VALUE_INFINITE);
    assert(PvNode || (alpha == beta - 1));
    assert(depth <= 0.0f);
    assert(0 <= ss->ply && ss->ply < MAX_PLY);

    // Step 1. Initialize node
    SearchThread *thisThread = board.thisThread();
#ifdef POLICY_TRAINING
    const bool     policyTraceEnabled    = thisThread->engine.policyTraceSession() != nullptr;
    const uint64_t policyTraceNodeStart  = thisThread->numNodes.load(std::memory_order_relaxed);
    const Time     policyTraceEventStart = policyTraceEnabled ? now() : Time(0);
#endif
    thisThread->numNodes.fetch_add(1, std::memory_order_relaxed);

    Color self      = board.sideToMove();
    int   moveCount = 0;
    Value bestValue = -VALUE_INFINITE, value;
    Value oldAlpha  = alpha;  // Flag BOUND_EXACT when value above alpha in PVNode
    Pos   bestMove  = Pos::NONE;

    // Update selDepth (selDepth counts from 1, ply from 0)
    if (PvNode && thisThread->selDepth <= ss->ply)
        thisThread->selDepth = ss->ply + 1;

    // Step 2. Check for immediate draw and winning
    // Check if we reach the time limit
    if (thisThread->isMainThread())
        thisThread->engine.ctx.checkExit();

    // Check if the board has been filled or we have reached the max game ply.
    if (board.movesLeft() == 0 || board.nonPassMoveCount() >= thisThread->options().maxMoves)
        return getDrawValue(board, thisThread->options(), ss->ply);

    // Check if we reached the max ply
    if (ss->ply >= MAX_PLY)
        return Evaluation::evaluate<Rule>(board, alpha, beta);

    // Check for immediate winning
    if ((value = quickWinCheck<Rule>(board, ss->ply, beta)) != VALUE_ZERO) {
        // Do not return mate that longer than maxMoves option
        if (board.nonPassMoveCount() + mate_step(value, ss->ply) > thisThread->options().maxMoves)
            value = getDrawValue(board, thisThread->options(), ss->ply);

        return value;
    }

    // Step 3. Mate distance pruning
    alpha = std::max(mated_in(ss->ply), alpha);
    beta  = std::min(mate_in(ss->ply + 1), beta);
    if (alpha >= beta)
        return alpha;

    // Step 4. Transposition table lookup
    HashKey posKey  = board.zobristKey();
    Value   ttValue = VALUE_NONE;
    Value   ttEval  = VALUE_NONE;
    bool    ttIsPv  = false;
    Bound   ttBound = BOUND_NONE;
    Pos     ttMove  = Pos::NONE;
    int     ttDepth = (int)DEPTH_LOWER_BOUND;
    bool    ttHit   = TT.probe(posKey, ttValue, ttEval, ttIsPv, ttBound, ttMove, ttDepth, ss->ply);

    // Check for an early TT cutoff (for all types of nodes)
    if (ttHit && ttDepth >= depth && (!PvNode || !thisThread->isMainThread())  // Show full PV
    ) {
        if (ttBound & BOUND_LOWER)
            alpha = std::max(alpha, ttValue);
        if (ttBound & BOUND_UPPER)
            beta = std::min(beta, ttValue);
        if (alpha >= beta)
            return ttValue;
    }

    // Step 5. Static position evaluation
    if (ttHit) {
        // Never assume anything about values stored in TT
        bestValue = ss->staticEval = ttEval;
        if (bestValue == VALUE_NONE)
            bestValue = ss->staticEval = Evaluation::evaluate<Rule>(board, alpha, beta);

        // Try to use ttValue as a better eval estimation
        if (ttValue != VALUE_NONE
            && (ttBound & (ttValue > ss->staticEval ? BOUND_LOWER : BOUND_UPPER)))
            bestValue = ttValue;
    }
    else {
        // In case of null move search use previous static eval with a different sign
        bestValue = ss->staticEval = (ss - 1)->currentMove == Pos::PASS
                                         ? -(ss - 1)->staticEval
                                         : Evaluation::evaluate<Rule>(board, alpha, beta);
    }

    // Stand pat. Return immediately if static value is at least beta
    if (bestValue >= beta) {
        // Save static evaluation into transposition table
        if (!ttHit)
            TT.store(posKey,
                     bestValue,
                     ss->staticEval,
                     false,
                     BOUND_LOWER,
                     Pos::NONE,
                     (int)DEPTH_NONE,
                     ss->ply);

        return bestValue;
    }
    // Keep improving alpha since we can stop anywhere in the move limited search.
    else if (PvNode && bestValue > alpha)
        alpha = bestValue;

    // Step 6. Delta pruning at non-PV node
    if (!PvNode && bestValue + qvcfDeltaMargin<Rule>(depth) < alpha) {
        // Save static evaluation into transposition table
        if (!ttHit)
            TT.store(posKey,
                     alpha,
                     ss->staticEval,
                     false,
                     BOUND_UPPER,
                     Pos::NONE,
                     (int)DEPTH_NONE,
                     ss->ply);

        return alpha;
    }

    // Step 7. Loop through the moves until no moves remain or a beta cutoff occurs.
#ifdef POLICY_TRAINING
    const Value         policyTraceAlpha = alpha;
    const Value         policyTraceBeta  = beta;
    const Depth         policyTraceDepth = depth;
    DeferredPolicyTrace deferredPolicyTrace;
    bool                policyTraceInitialized = false;
#endif
    MovePicker mp(
        Rule,
        board,
        MovePicker::ExtraArgs<MovePicker::QVCF> {ttMove,
                                                 depth,
                                                 {(ss - 2)->moveP4[self], (ss - 4)->moveP4[self]}});

    while (Pos move = mp()) {
#ifdef POLICY_TRAINING
        initializePolicyTraceEvent<NT>(mp,
                                       ss,
                                       policyTraceAlpha,
                                       policyTraceBeta,
                                       policyTraceDepth,
                                       false,
                                       deferredPolicyTrace,
                                       policyTraceInitialized);
        Tuning::PolicyTraceCandidate *policyTraceCandidate = mp.policyTraceCandidate(move);
        DeferredPolicyTrace           currentPolicyTrace;
        currentPolicyTrace.move             = move;
        currentPolicyTrace.filter =
            move == ttMove ? Tuning::PolicyTraceFilter::TtMove
                           : Tuning::PolicyTraceFilter::None;
        currentPolicyTrace.alphaBefore      = alpha;
        currentPolicyTrace.moveCount        = static_cast<uint16_t>(moveCount + 1);
        currentPolicyTrace.valid            = true;
        const uint64_t policyTraceMoveStart = thisThread->numNodes.load(std::memory_order_relaxed);
        recordPolicyTraceSearch(currentPolicyTrace, depth - 1);
#endif
        assert(board.isLegal(move));

        ss->currentMove   = move;
        ss->moveCount     = ++moveCount;
        ss->moveP4[BLACK] = board.pattern4(move, BLACK);
        ss->moveP4[WHITE] = board.pattern4(move, WHITE);
        if (PvNode)
            (ss + 1)->pv[0] = Pos::NONE;

        // Step 8. Make and search the move
        board.move<Rule>(move);

        // Call defence-side vcf search
        value = -vcfdefend<Rule, NT>(board, ss + 1, -beta, -alpha, depth - 1);

        board.undo<Rule>();

        // Check if a stop occurred, we discard search result by returning none value
        if (thisThread->engine.isTerminating())
            return VALUE_NONE;

#ifdef POLICY_TRAINING
        currentPolicyTrace.value = value;
        currentPolicyTrace.bound = value >= beta                             ? BOUND_LOWER
                                   : value <= currentPolicyTrace.alphaBefore ? BOUND_UPPER
                                                                             : BOUND_EXACT;
        currentPolicyTrace.nodes =
            thisThread->numNodes.load(std::memory_order_relaxed) - policyTraceMoveStart;
        currentPolicyTrace.alphaChanged = value > currentPolicyTrace.alphaBefore;
        currentPolicyTrace.disposition =
            value >= beta ? Tuning::PolicyTraceDisposition::SearchedCutoff
            : value > currentPolicyTrace.alphaBefore
                ? Tuning::PolicyTraceDisposition::SearchedAlphaImprovement
                : Tuning::PolicyTraceDisposition::SearchedFailLow;
        if (policyTraceCandidate)
            applyDeferredPolicyTrace(*policyTraceCandidate, currentPolicyTrace);
        else
            deferredPolicyTrace = currentPolicyTrace;
#endif

        // Step 9. Check for a new best move
        if (value > bestValue) {
            bestValue = value;

            if (value > alpha) {
                bestMove = move;

                if (PvNode)  // Update pv even in fail-high case
                    ss->updatePv(move);

                if (PvNode && value < beta)  // Update alpha
                    alpha = value;
                else  // Fail high
                    break;
            }
        }
    }

    // Step 10. Save TT entry for this position
    Bound bound = bestValue >= beta                ? BOUND_LOWER
                  : PvNode && bestValue > oldAlpha ? BOUND_EXACT
                                                   : BOUND_UPPER;
#ifdef POLICY_TRAINING
    initializePolicyTraceEvent<NT>(mp,
                                   ss,
                                   policyTraceAlpha,
                                   policyTraceBeta,
                                   policyTraceDepth,
                                   false,
                                   deferredPolicyTrace,
                                   policyTraceInitialized);
    finishPolicyTraceEvent(mp,
                           *thisThread,
                           policyTraceNodeStart,
                           policyTraceEventStart,
                           bestValue,
                           bestMove,
                           bound);
#endif
    TT.store(posKey,
             bestValue,
             ss->staticEval,
             PvNode,
             bound,
             bestMove,
             (int)std::max(depth, DEPTH_QVCF),
             ss->ply);

    assert(bestValue > -VALUE_INFINITE && bestValue < VALUE_INFINITE);
    return bestValue;
}

/// The search function for defend node in VCF search.
template <Rule Rule, NodeType NT>
Value vcfdefend(Board &board, SearchStack *ss, Value alpha, Value beta, Depth depth)
{
    constexpr bool PvNode = NT == PV || NT == Root;

    // Do some sanity check over input arguments
    assert(-VALUE_INFINITE <= alpha && alpha < beta && beta <= VALUE_INFINITE);
    assert(PvNode || (alpha == beta - 1));
    assert(depth <= 0.0f);
    assert(0 <= ss->ply && ss->ply < MAX_PLY);

    // Step 1. Initialize node
    SearchThread *thisThread = board.thisThread();
    thisThread->numNodes.fetch_add(1, std::memory_order_relaxed);

    Color    self = board.sideToMove(), oppo = ~self;
    uint16_t oppo5 = board.p4Count(oppo, A_FIVE);  // opponent five
    Value    value;

    // Update selDepth (selDepth counts from 1, ply from 0)
    if (PvNode && thisThread->selDepth <= ss->ply)
        thisThread->selDepth = ss->ply + 1;

    // Step 2. Check for immediate evaluation, draw and winning
    // Return evaluation immediately if there is no vcf threat
    if (!oppo5)
        return Evaluation::evaluate<Rule>(board, alpha, beta);

    // Check if the board has been filled or we have reached the max game ply.
    if (board.movesLeft() == 0 || board.nonPassMoveCount() >= thisThread->options().maxMoves)
        return getDrawValue(board, thisThread->options(), ss->ply);

    // Check if we reached the max ply
    if (ss->ply >= MAX_PLY)
        return Evaluation::evaluate<Rule>(board, alpha, beta);

    // Step 3. Search the only defence move
    Pos move = board.stateInfo().lastPattern4(oppo, A_FIVE);
    assert(board.pattern4(move, oppo) == A_FIVE);

    // For renju, if black's defence move is a forbidden point, black loses in two steps.
    if (Rule == Rule::RENJU && self == BLACK && board.checkForbiddenPoint(move)) {
        value = mated_in(ss->ply + 2);
    }
    else {
        ss->currentMove   = move;
        ss->moveCount     = 1;
        ss->moveP4[BLACK] = board.pattern4(move, BLACK);
        ss->moveP4[WHITE] = board.pattern4(move, WHITE);
        if (PvNode)
            (ss + 1)->pv[0] = Pos::NONE;

        TT.prefetch(board.zobristKeyAfter(move));  // pre-make: see Step 14 of search()
        board.move<Rule>(move);

        // Call attack-side vcf search
        // Note that we do not reduce depth for vcf defence move.
        value = -vcfsearch<Rule, NT>(board, ss + 1, -beta, -alpha, depth);

        board.undo<Rule>();

        // Update pv in PV node
        if (PvNode)
            ss->updatePv(move);
    }

    assert(value > -VALUE_INFINITE && value < VALUE_INFINITE || thisThread->engine.isTerminating());
    return value;
}

}  // namespace
